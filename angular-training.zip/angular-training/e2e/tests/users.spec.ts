import { test, expect, Page } from '@playwright/test';

/**
 * END-TO-END TESTING CONCEPTS FOR USERS PAGE:
 * 
 * 1. Page Object Model - Organizing test code using page objects for reusability
 * 2. User Journey Testing - Testing complete user workflows from start to finish
 * 3. Search and Filter Testing - Testing real-time search functionality
 * 4. Performance Testing - Testing page load times and responsiveness
 * 5. Accessibility Testing - Testing keyboard navigation and screen reader support
 * 6. Mobile Responsiveness - Testing responsive design on different screen sizes
 * 7. Error State Testing - Testing error handling and edge cases
 * 8. Data Loading Testing - Testing async data loading and loading states
 * 9. Navigation Testing - Testing routing and deep linking
 * 10. Visual Regression Testing - Testing UI consistency across changes
 */

/**
 * PAGE OBJECT MODEL FOR USERS PAGE
 * 
 * This class encapsulates all page-specific selectors and actions,
 * making tests more maintainable and reducing code duplication.
 */
class UsersPage {
  constructor(private page: Page) {}

  // Navigation methods
  async goto() {
    await this.page.goto('/users');
    await this.waitForPageLoad();
  }

  async waitForPageLoad() {
    // Wait for users to load (replace with actual loading indicator)
    await this.page.waitForSelector('.users-grid, .loading', { timeout: 10000 });
    
    // If loading indicator is present, wait for it to disappear
    const loadingSelector = '.loading, .spinner';
    if (await this.page.locator(loadingSelector).isVisible()) {
      await this.page.waitForSelector(loadingSelector, { state: 'hidden', timeout: 10000 });
    }
  }

  // Search functionality methods
  async searchUsers(searchTerm: string) {
    await this.page.fill('.search-input, [placeholder*="Search"]', searchTerm);
    // Wait for search debouncing
    await this.page.waitForTimeout(300);
  }

  async clearSearch() {
    await this.page.fill('.search-input, [placeholder*="Search"]', '');
    await this.page.waitForTimeout(300);
  }

  async getSearchInput() {
    return this.page.locator('.search-input, [placeholder*="Search"]');
  }

  // User card interaction methods
  getUserCards() {
    return this.page.locator('.user-card, .card');
  }

  async getUserCardCount() {
    return await this.getUserCards().count();
  }

  async clickUserCard(index: number = 0) {
    const userCards = this.getUserCards();
    await userCards.nth(index).click();
  }

  async getUserCardInfo(index: number = 0) {
    const userCard = this.getUserCards().nth(index);
    const name = await userCard.locator('.user-name, h3, .name').textContent();
    const email = await userCard.locator('.user-email, .email').textContent();
    const company = await userCard.locator('.user-company, .company').textContent();
    
    return { name, email, company };
  }

  // Statistics methods
  async getStatistics() {
    const statCards = this.page.locator('.stat-card');
    const stats = [];
    
    const count = await statCards.count();
    for (let i = 0; i < count; i++) {
      const number = await statCards.nth(i).locator('.stat-number').textContent();
      const label = await statCards.nth(i).locator('.stat-label').textContent();
      stats.push({ number: parseInt(number || '0'), label });
    }
    
    return stats;
  }

  // Error state methods
  async hasErrorMessage() {
    return await this.page.locator('.error-message, .alert-error').isVisible();
  }

  async getErrorMessage() {
    return await this.page.locator('.error-message, .alert-error').textContent();
  }

  // Loading state methods
  async isLoading() {
    return await this.page.locator('.loading, .spinner').isVisible();
  }

  // Empty state methods
  async hasNoResults() {
    return await this.page.locator('.no-results, .empty-state').isVisible();
  }

  async getNoResultsMessage() {
    return await this.page.locator('.no-results, .empty-state').textContent();
  }

  // Accessibility methods
  async navigateWithKeyboard() {
    await this.page.keyboard.press('Tab');
    return await this.page.locator(':focus').textContent();
  }

  async isSearchInputFocused() {
    const searchInput = await this.getSearchInput();
    return await searchInput.evaluate(el => el === document.activeElement);
  }
}

/**
 * TEST SUITE FOR USERS PAGE
 */
test.describe('Users Page - E2E Tests', () => {
  let usersPage: UsersPage;

  test.beforeEach(async ({ page }) => {
    usersPage = new UsersPage(page);
    await usersPage.goto();
  });

  /**
   * BASIC PAGE FUNCTIONALITY TESTS
   * Testing core page loading and initial state
   */
  test.describe('Page Loading and Basic Functionality', () => {
    test('should load users page successfully', async ({ page }) => {
      // Test page title and main heading
      await expect(page).toHaveTitle(/Angular Training/);
      await expect(page.locator('h1')).toContainText(/Users/i);
    });

    test('should display user cards after loading', async () => {
      // Wait for users to load and verify cards are displayed
      const userCardCount = await usersPage.getUserCardCount();
      expect(userCardCount).toBeGreaterThan(0);
    });

    test('should display search input', async ({ page }) => {
      const searchInput = await usersPage.getSearchInput();
      await expect(searchInput).toBeVisible();
      await expect(searchInput).toHaveAttribute('placeholder', /search/i);
    });

    test('should display statistics cards', async () => {
      const stats = await usersPage.getStatistics();
      expect(stats.length).toBeGreaterThanOrEqual(1);
      
      // Verify statistics have meaningful data
      const totalUsersStats = stats.find(stat => 
        stat.label?.toLowerCase().includes('total') || 
        stat.label?.toLowerCase().includes('users')
      );
      expect(totalUsersStats?.number).toBeGreaterThan(0);
    });

    test('should not show loading indicator after page loads', async () => {
      const isLoading = await usersPage.isLoading();
      expect(isLoading).toBeFalsy();
    });
  });

  /**
   * SEARCH FUNCTIONALITY TESTS
   * Testing real-time search and filtering capabilities
   */
  test.describe('Search Functionality', () => {
    test('should filter users by name', async () => {
      // Get initial user count
      const initialCount = await usersPage.getUserCardCount();
      expect(initialCount).toBeGreaterThan(1);
      
      // Search for a specific user (assuming there's a user with "John" in the name)
      await usersPage.searchUsers('John');
      
      // Verify filtered results
      const filteredCount = await usersPage.getUserCardCount();
      expect(filteredCount).toBeLessThanOrEqual(initialCount);
      
      // Verify all visible users contain the search term
      const userCards = usersPage.getUserCards();
      const count = await userCards.count();
      
      for (let i = 0; i < count; i++) {
        const userInfo = await usersPage.getUserCardInfo(i);
        const containsSearchTerm = 
          userInfo.name?.toLowerCase().includes('john') ||
          userInfo.email?.toLowerCase().includes('john') ||
          userInfo.company?.toLowerCase().includes('john');
        expect(containsSearchTerm).toBeTruthy();
      }
    });

    test('should filter users by email', async () => {
      // Search by email domain
      await usersPage.searchUsers('@example.com');
      
      const userCards = usersPage.getUserCards();
      const count = await userCards.count();
      
      // Verify results contain the email domain
      for (let i = 0; i < count; i++) {
        const userInfo = await usersPage.getUserCardInfo(i);
        expect(userInfo.email?.toLowerCase()).toContain('@example.com');
      }
    });

    test('should filter users by company', async () => {
      // Get first user's company to search for
      const firstUserInfo = await usersPage.getUserCardInfo(0);
      const companyToSearch = firstUserInfo.company?.split(' ')[0]; // Get first word of company name
      
      if (companyToSearch) {
        await usersPage.searchUsers(companyToSearch);
        
        const userCards = usersPage.getUserCards();
        const count = await userCards.count();
        
        // Verify all results match the company search
        for (let i = 0; i < count; i++) {
          const userInfo = await usersPage.getUserCardInfo(i);
          expect(userInfo.company?.toLowerCase()).toContain(companyToSearch.toLowerCase());
        }
      }
    });

    test('should show all users when search is cleared', async () => {
      // Get initial count
      const initialCount = await usersPage.getUserCardCount();
      
      // Apply search filter
      await usersPage.searchUsers('John');
      const filteredCount = await usersPage.getUserCardCount();
      
      // Clear search
      await usersPage.clearSearch();
      const finalCount = await usersPage.getUserCardCount();
      
      // Should return to initial count
      expect(finalCount).toBe(initialCount);
    });

    test('should handle search with no results', async () => {
      // Search for something that definitely won't exist
      await usersPage.searchUsers('xyz123nonexistent');
      
      const userCardCount = await usersPage.getUserCardCount();
      expect(userCardCount).toBe(0);
      
      // Check for no results message (if implemented)
      const hasNoResults = await usersPage.hasNoResults();
      if (hasNoResults) {
        const noResultsMessage = await usersPage.getNoResultsMessage();
        expect(noResultsMessage?.toLowerCase()).toContain('no');
      }
    });

    test('should be case insensitive', async () => {
      // Search with different cases
      await usersPage.searchUsers('JOHN');
      const uppercaseCount = await usersPage.getUserCardCount();
      
      await usersPage.clearSearch();
      await usersPage.searchUsers('john');
      const lowercaseCount = await usersPage.getUserCardCount();
      
      await usersPage.clearSearch();
      await usersPage.searchUsers('John');
      const capitalizedCount = await usersPage.getUserCardCount();
      
      // All should return the same results
      expect(uppercaseCount).toBe(lowercaseCount);
      expect(lowercaseCount).toBe(capitalizedCount);
    });

    test('should update statistics when filtering', async () => {
      // Get initial statistics
      const initialStats = await usersPage.getStatistics();
      const initialTotalUsers = initialStats.find(stat => 
        stat.label?.toLowerCase().includes('total') || 
        stat.label?.toLowerCase().includes('users')
      );
      
      // Apply filter
      await usersPage.searchUsers('John');
      
      // Get updated statistics
      const filteredStats = await usersPage.getStatistics();
      const filteredTotalUsers = filteredStats.find(stat => 
        stat.label?.toLowerCase().includes('total') || 
        stat.label?.toLowerCase().includes('users')
      );
      
      // Statistics should update to reflect filtered data
      expect(filteredTotalUsers?.number).toBeLessThanOrEqual(initialTotalUsers?.number || 0);
    });
  });

  /**
   * USER INTERACTION TESTS
   * Testing user card interactions and navigation
   */
  test.describe('User Interactions', () => {
    test('should navigate to user detail on card click', async ({ page }) => {
      // Click on the first user card
      await usersPage.clickUserCard(0);
      
      // Wait for navigation
      await page.waitForURL('**/user/**', { timeout: 5000 });
      
      // Verify we navigated to user detail page
      expect(page.url()).toMatch(/\/user\/\d+/);
    });

    test('should show user information correctly', async () => {
      const userInfo = await usersPage.getUserCardInfo(0);
      
      // Verify user information is displayed
      expect(userInfo.name).toBeTruthy();
      expect(userInfo.email).toBeTruthy();
      expect(userInfo.email).toContain('@');
      expect(userInfo.company).toBeTruthy();
    });

    test('should handle hover effects on user cards', async ({ page }) => {
      const userCards = usersPage.getUserCards();
      const firstCard = userCards.first();
      
      // Hover over the card
      await firstCard.hover();
      
      // Check if hover state is applied (this depends on CSS implementation)
      // We can check if any hover-related classes or styles are applied
      const hoverClass = await firstCard.getAttribute('class');
      expect(hoverClass).toBeTruthy();
    });
  });

  /**
   * RESPONSIVE DESIGN TESTS
   * Testing mobile and tablet layouts
   */
  test.describe('Responsive Design', () => {
    test('should display correctly on mobile devices', async ({ page }) => {
      // Set mobile viewport
      await page.setViewportSize({ width: 375, height: 667 });
      await usersPage.goto();
      
      // Verify search input is visible and accessible
      const searchInput = await usersPage.getSearchInput();
      await expect(searchInput).toBeVisible();
      
      // Verify user cards are stacked vertically on mobile
      const userCards = usersPage.getUserCards();
      const count = await userCards.count();
      
      if (count >= 2) {
        const firstCardBox = await userCards.nth(0).boundingBox();
        const secondCardBox = await userCards.nth(1).boundingBox();
        
        // On mobile, cards should be stacked (second card should be below first)
        expect(secondCardBox?.y).toBeGreaterThan(firstCardBox?.y || 0);
      }
    });

    test('should display correctly on tablet devices', async ({ page }) => {
      // Set tablet viewport
      await page.setViewportSize({ width: 768, height: 1024 });
      await usersPage.goto();
      
      // Verify layout adapts to tablet screen
      const userCards = usersPage.getUserCards();
      await expect(userCards.first()).toBeVisible();
    });

    test('should hide/show elements based on screen size', async ({ page }) => {
      // Test desktop view
      await page.setViewportSize({ width: 1024, height: 768 });
      await usersPage.goto();
      
      // Check if all elements are visible on desktop
      const stats = await usersPage.getStatistics();
      expect(stats.length).toBeGreaterThan(0);
      
      // Test mobile view
      await page.setViewportSize({ width: 375, height: 667 });
      
      // Some elements might be hidden or reorganized on mobile
      // This test verifies the layout adapts appropriately
      const searchInput = await usersPage.getSearchInput();
      await expect(searchInput).toBeVisible();
    });
  });

  /**
   * ACCESSIBILITY TESTS
   * Testing keyboard navigation and screen reader support
   */
  test.describe('Accessibility', () => {
    test('should support keyboard navigation', async ({ page }) => {
      // Focus should start at search input or first focusable element
      await page.keyboard.press('Tab');
      
      const focusedElement = await page.locator(':focus');
      await expect(focusedElement).toBeVisible();
    });

    test('should allow search input to be accessible via keyboard', async ({ page }) => {
      const searchInput = await usersPage.getSearchInput();
      
      // Focus the search input
      await searchInput.focus();
      
      // Type a search term
      await page.keyboard.type('John');
      
      // Verify the input value changed
      const inputValue = await searchInput.inputValue();
      expect(inputValue).toBe('John');
    });

    test('should have proper ARIA labels and roles', async ({ page }) => {
      // Check for proper ARIA attributes on search input
      const searchInput = await usersPage.getSearchInput();
      const ariaLabel = await searchInput.getAttribute('aria-label');
      const placeholder = await searchInput.getAttribute('placeholder');
      
      // Should have either aria-label or meaningful placeholder
      expect(ariaLabel || placeholder).toBeTruthy();
      
      // Check for proper heading structure
      const mainHeading = page.locator('h1');
      await expect(mainHeading).toBeVisible();
    });

    test('should support screen reader navigation', async ({ page }) => {
      // Check for proper heading hierarchy
      const headings = page.locator('h1, h2, h3, h4, h5, h6');
      const headingCount = await headings.count();
      expect(headingCount).toBeGreaterThan(0);
      
      // Check for alternative text on images (if any)
      const images = page.locator('img');
      const imageCount = await images.count();
      
      for (let i = 0; i < imageCount; i++) {
        const img = images.nth(i);
        const alt = await img.getAttribute('alt');
        const ariaLabel = await img.getAttribute('aria-label');
        
        // Images should have alt text or aria-label
        expect(alt || ariaLabel).toBeTruthy();
      }
    });
  });

  /**
   * PERFORMANCE TESTS
   * Testing page load times and responsiveness
   */
  test.describe('Performance', () => {
    test('should load page within acceptable time', async ({ page }) => {
      const startTime = Date.now();
      await usersPage.goto();
      const loadTime = Date.now() - startTime;
      
      // Page should load within 5 seconds
      expect(loadTime).toBeLessThan(5000);
    });

    test('should handle rapid search input changes', async ({ page }) => {
      const searchInput = await usersPage.getSearchInput();
      
      // Type rapidly and verify app doesn't crash
      const searchTerms = ['a', 'ab', 'abc', 'abcd', 'abc', 'ab', 'a', ''];
      
      for (const term of searchTerms) {
        await searchInput.fill(term);
        await page.waitForTimeout(50); // Simulate rapid typing
      }
      
      // Verify page is still functional
      const userCards = usersPage.getUserCards();
      await expect(userCards.first()).toBeVisible();
    });

    test('should maintain scroll position during search', async ({ page }) => {
      // Scroll down the page
      await page.mouse.wheel(0, 500);
      const initialScrollY = await page.evaluate(() => window.scrollY);
      
      // Perform search
      await usersPage.searchUsers('John');
      
      // Verify scroll position (might reset for filtered results, depends on implementation)
      const finalScrollY = await page.evaluate(() => window.scrollY);
      
      // This test verifies the behavior is consistent
      expect(typeof finalScrollY).toBe('number');
    });
  });

  /**
   * ERROR HANDLING TESTS
   * Testing error states and edge cases
   */
  test.describe('Error Handling', () => {
    test('should handle network errors gracefully', async ({ page }) => {
      // Simulate network failure
      await page.route('**/api/users**', route => route.abort());
      
      await usersPage.goto();
      
      // Check if error message is displayed
      const hasError = await usersPage.hasErrorMessage();
      if (hasError) {
        const errorMessage = await usersPage.getErrorMessage();
        expect(errorMessage?.toLowerCase()).toContain('error');
      }
    });

    test('should handle empty search results gracefully', async () => {
      await usersPage.searchUsers('nonexistentuser12345');
      
      const userCardCount = await usersPage.getUserCardCount();
      expect(userCardCount).toBe(0);
      
      // Should show appropriate message for no results
      const hasNoResults = await usersPage.hasNoResults();
      if (hasNoResults) {
        const message = await usersPage.getNoResultsMessage();
        expect(message).toBeTruthy();
      }
    });

    test('should handle special characters in search', async () => {
      const specialChars = ['!@#$%', '<script>', '&amp;', '"quotes"'];
      
      for (const chars of specialChars) {
        await usersPage.searchUsers(chars);
        
        // App should not crash with special characters
        const searchInput = await usersPage.getSearchInput();
        await expect(searchInput).toBeVisible();
        
        await usersPage.clearSearch();
      }
    });
  });

  /**
   * INTEGRATION TESTS
   * Testing integration with other parts of the application
   */
  test.describe('Integration Tests', () => {
    test('should integrate with navigation system', async ({ page }) => {
      // Test navigation from home to users page
      await page.goto('/');
      
      // Find and click users navigation link
      const usersLink = page.locator('a[href*="users"], a:has-text("Users")');
      if (await usersLink.isVisible()) {
        await usersLink.click();
        await page.waitForURL('**/users**');
        expect(page.url()).toContain('/users');
      }
    });

    test('should maintain state across browser refresh', async ({ page }) => {
      // Apply search filter
      await usersPage.searchUsers('John');
      const filteredCount = await usersPage.getUserCardCount();
      
      // Refresh the page
      await page.reload();
      await usersPage.waitForPageLoad();
      
      // Check if search state is maintained (depends on implementation)
      const searchInput = await usersPage.getSearchInput();
      const searchValue = await searchInput.inputValue();
      
      // This test documents the expected behavior
      expect(typeof searchValue).toBe('string');
    });

    test('should work with browser back/forward buttons', async ({ page }) => {
      // Navigate to users page
      await usersPage.goto();
      
      // Click on a user card to navigate to detail page
      await usersPage.clickUserCard(0);
      await page.waitForURL('**/user/**', { timeout: 5000 });
      
      // Use browser back button
      await page.goBack();
      await page.waitForURL('**/users**');
      
      // Verify we're back on users page
      expect(page.url()).toContain('/users');
      const userCards = usersPage.getUserCards();
      await expect(userCards.first()).toBeVisible();
    });
  });
});
