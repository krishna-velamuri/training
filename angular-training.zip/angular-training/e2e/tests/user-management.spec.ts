import { test, expect, Page } from '@playwright/test';

/**
 * End-to-End tests for User Management functionality
 * 
 * This test suite demonstrates advanced e2e testing concepts:
 * 1. Testing CRUD operations in the browser
 * 2. Testing data persistence and state management
 * 3. Testing user interactions with lists and details
 * 4. Testing search and filtering functionality
 * 5. Testing error handling in user interfaces
 * 6. Testing data validation and user feedback
 */

test.describe('User Management Flow', () => {
  let page: Page;

  /**
   * Setup hook for user management tests
   */
  test.beforeEach(async ({ page: testPage }) => {
    page = testPage;
    
    // Navigate to the users page
    await page.goto('/users');
    await page.waitForLoadState('networkidle');
  });

  /**
   * Test users page loading and structure
   * This verifies the users page displays correctly
   */
  test('should display users list correctly', async () => {
    // Verify page title and heading
    await expect(page.locator('h1, h2')).toContainText(/Users/i);
    
    // Check that users are displayed in some format (list, grid, table)
    const userContainer = page.locator('.user-list, .users-grid, .users-container, table, .list-container');
    
    // The page should have some container for users (even if empty)
    const pageContent = await page.textContent('body');
    expect(pageContent).toBeTruthy();
    
    // Look for user-related content or empty state message
    const hasUsers = await page.locator('.user-item, .user-card, tr, .user').count() > 0;
    const hasEmptyState = pageContent?.includes('No users') || pageContent?.includes('empty');
    
    // Either users should be displayed or there should be an empty state
    expect(hasUsers || hasEmptyState).toBeTruthy();
  });

  /**
   * Test user search functionality (if available)
   * This demonstrates testing search and filtering features
   */
  test('should handle user search if available', async () => {
    // Look for search input
    const searchInput = page.locator('input[type="search"], input[placeholder*="search" i], input[placeholder*="filter" i]');
    
    if (await searchInput.isVisible()) {
      // Test search functionality
      await searchInput.fill('john');
      
      // Wait for search results
      await page.waitForTimeout(500);
      
      // Verify search results
      const userItems = page.locator('.user-item, .user-card, tr, .user');
      const userCount = await userItems.count();
      
      if (userCount > 0) {
        // If users are found, verify they contain the search term
        const firstUserText = await userItems.first().textContent();
        expect(firstUserText?.toLowerCase()).toContain('john');
      }
      
      // Clear search
      await searchInput.clear();
      await page.waitForTimeout(500);
    } else {
      // If no search is available, that's fine - skip this test
      console.log('Search functionality not available on users page');
    }
  });

  /**
   * Test user detail navigation (if available)
   * This demonstrates testing navigation to detail views
   */
  test('should navigate to user details if available', async () => {
    // Look for clickable user items or detail links
    const userLinks = page.locator('a[href*="/user"], .user-item[role="button"], .user-card[role="button"]');
    const userButtons = page.locator('button:has-text("View"), button:has-text("Details"), .user-item button');
    
    // Check if we can navigate to user details
    const clickableUsers = await userLinks.count() + await userButtons.count();
    
    if (clickableUsers > 0) {
      // Click on the first available user
      if (await userLinks.first().isVisible()) {
        await userLinks.first().click();
      } else if (await userButtons.first().isVisible()) {
        await userButtons.first().click();
      }
      
      // Wait for navigation or modal
      await page.waitForTimeout(1000);
      
      // Check if we navigated to a detail page or opened a modal
      const currentUrl = page.url();
      const modalPresent = await page.locator('.modal, .dialog, .popup').isVisible();
      
      if (currentUrl.includes('/user/') || modalPresent) {
        // Verify user detail content
        const detailContent = page.locator('.user-detail, .user-info, .modal-content, .dialog-content');
        await expect(detailContent).toBeVisible();
        
        // If it's a modal, close it
        if (modalPresent) {
          const closeButton = page.locator('.modal-close, .close, [aria-label="Close"]');
          if (await closeButton.isVisible()) {
            await closeButton.click();
          }
        } else {
          // If we navigated, go back
          await page.goBack();
        }
      }
    } else {
      console.log('User detail navigation not available');
    }
  });

  /**
   * Test add user functionality (if available)
   * This demonstrates testing create operations
   */
  test('should handle add user functionality if available', async () => {
    // Look for add user button
    const addUserButton = page.locator(
      'button:has-text("Add"), button:has-text("New"), button:has-text("Create"), .add-user, .new-user'
    );
    
    if (await addUserButton.isVisible()) {
      await addUserButton.click();
      
      // Wait for form or modal to appear
      await page.waitForTimeout(1000);
      
      // Look for user form
      const userForm = page.locator('form, .user-form, .add-user-form');
      const modal = page.locator('.modal, .dialog');
      
      if (await userForm.isVisible()) {
        // Verify form fields are present
        const nameInput = page.locator('input[name*="name" i], input[placeholder*="name" i]');
        const emailInput = page.locator('input[type="email"], input[name*="email" i]');
        
        if (await nameInput.isVisible() && await emailInput.isVisible()) {
          // Fill out basic form fields
          await nameInput.fill('Test User');
          await emailInput.fill('test@example.com');
          
          // Look for submit button
          const submitButton = page.locator(
            'button[type="submit"], button:has-text("Save"), button:has-text("Create"), button:has-text("Add")'
          );
          
          if (await submitButton.isVisible()) {
            // Don't actually submit in tests unless we want to test the full flow
            // Just verify the form is functional
            expect(await nameInput.inputValue()).toBe('Test User');
            expect(await emailInput.inputValue()).toBe('test@example.com');
          }
        }
        
        // Close form/modal if possible
        const cancelButton = page.locator('button:has-text("Cancel"), .cancel, [aria-label="Close"]');
        if (await cancelButton.isVisible()) {
          await cancelButton.click();
        }
      }
    } else {
      console.log('Add user functionality not available');
    }
  });

  /**
   * Test users page responsiveness
   * This demonstrates testing responsive design for data displays
   */
  test('should be responsive on different screen sizes', async () => {
    const viewports = [
      { width: 320, height: 568, name: 'Mobile' },
      { width: 768, height: 1024, name: 'Tablet' },
      { width: 1200, height: 800, name: 'Desktop' }
    ];
    
    for (const viewport of viewports) {
      await page.setViewportSize(viewport);
      
      // Verify page content is still accessible
      const heading = page.locator('h1, h2');
      await expect(heading).toBeVisible();
      
      // Check that content doesn't overflow horizontally
      const bodyScrollWidth = await page.evaluate(() => document.body.scrollWidth);
      const viewportWidth = viewport.width;
      expect(bodyScrollWidth).toBeLessThanOrEqual(viewportWidth + 20); // Small tolerance
      
      // Verify interactive elements are still accessible
      const buttons = page.locator('button, a[role="button"], .btn');
      const buttonCount = await buttons.count();
      
      if (buttonCount > 0) {
        const firstButton = buttons.first();
        await expect(firstButton).toBeVisible();
      }
    }
  });

  /**
   * Test users page accessibility
   * This demonstrates testing accessibility in data-heavy interfaces
   */
  test('should meet accessibility standards', async () => {
    // Test keyboard navigation
    await page.keyboard.press('Tab');
    
    // Verify focus is visible
    const focusedElement = page.locator(':focus');
    await expect(focusedElement).toBeVisible();
    
    // Test that list items are properly structured
    const listItems = page.locator('.user-item, .user-card, tr');
    const itemCount = await listItems.count();
    
    if (itemCount > 0) {
      // Navigate through items with keyboard
      for (let i = 0; i < Math.min(3, itemCount); i++) {
        await page.keyboard.press('Tab');
      }
    }
    
    // Check for proper heading structure
    const headings = page.locator('h1, h2, h3, h4, h5, h6');
    const headingCount = await headings.count();
    expect(headingCount).toBeGreaterThan(0);
    
    // Verify proper semantic structure
    const main = page.locator('main, [role="main"]');
    const lists = page.locator('ul, ol, table, [role="list"]');
    
    // Should have some semantic structure
    expect(await main.count() + await lists.count()).toBeGreaterThan(0);
  });

  /**
   * Test error handling in users interface
   * This demonstrates testing error scenarios
   */
  test('should handle errors gracefully', async () => {
    // Test page behavior when network is slow
    await page.route('**/*', route => {
      // Add delay to simulate slow network
      setTimeout(() => route.continue(), 100);
    });
    
    // Reload page with simulated slow network
    await page.reload();
    await page.waitForLoadState('networkidle');
    
    // Page should still load and function
    const heading = page.locator('h1, h2');
    await expect(heading).toBeVisible();
    
    // Remove network simulation
    await page.unroute('**/*');
  });

  /**
   * Test sorting functionality (if available)
   * This demonstrates testing data manipulation features
   */
  test('should handle sorting if available', async () => {
    // Look for sort buttons or headers
    const sortButtons = page.locator(
      'button:has-text("Sort"), th[role="button"], .sort-header, [data-sort]'
    );
    
    if (await sortButtons.count() > 0) {
      const firstSortButton = sortButtons.first();
      
      // Get initial order of items
      const userItems = page.locator('.user-item, .user-card, tr');
      const initialCount = await userItems.count();
      
      if (initialCount > 1) {
        const initialFirstItem = await userItems.first().textContent();
        
        // Click sort button
        await firstSortButton.click();
        await page.waitForTimeout(500);
        
        // Check if order changed
        const newFirstItem = await userItems.first().textContent();
        
        // The order might change, or there might be visual indicators of sorting
        const sortIndicators = page.locator('.sort-asc, .sort-desc, .sorted, [aria-sort]');
        const hasSortIndicator = await sortIndicators.count() > 0;
        
        // Either the order changed or there are sort indicators
        expect(initialFirstItem !== newFirstItem || hasSortIndicator).toBeTruthy();
      }
    } else {
      console.log('Sorting functionality not available');
    }
  });

  /**
   * Test pagination (if available)
   * This demonstrates testing pagination and data loading
   */
  test('should handle pagination if available', async () => {
    // Look for pagination controls
    const paginationControls = page.locator(
      '.pagination, .pager, button:has-text("Next"), button:has-text("Previous"), .page-number'
    );
    
    if (await paginationControls.count() > 0) {
      // Look for next button
      const nextButton = page.locator('button:has-text("Next"), .next, [aria-label*="next" i]');
      
      if (await nextButton.isVisible() && !await nextButton.isDisabled()) {
        // Get current page indicator
        const currentPage = page.locator('.current-page, .active, [aria-current="page"]');
        const initialPageText = await currentPage.textContent().catch(() => '1');
        
        // Click next
        await nextButton.click();
        await page.waitForTimeout(1000);
        
        // Verify page changed
        const newPageText = await currentPage.textContent().catch(() => '2');
        expect(newPageText).not.toBe(initialPageText);
        
        // Go back to first page
        const prevButton = page.locator('button:has-text("Previous"), .prev, [aria-label*="previous" i]');
        if (await prevButton.isVisible() && !await prevButton.isDisabled()) {
          await prevButton.click();
          await page.waitForTimeout(1000);
        }
      }
    } else {
      console.log('Pagination not available');
    }
  });

  /**
   * Test user list performance
   * This demonstrates testing performance of data-heavy interfaces
   */
  test('should perform well with user data', async () => {
    const startTime = Date.now();
    
    // Reload page and measure load time
    await page.reload();
    await page.waitForLoadState('networkidle');
    
    const loadTime = Date.now() - startTime;
    
    // Page should load within reasonable time
    expect(loadTime).toBeLessThan(5000);
    
    // Test scrolling performance (if applicable)
    const userItems = page.locator('.user-item, .user-card, tr');
    const itemCount = await userItems.count();
    
    if (itemCount > 5) {
      // Scroll through the list
      await page.evaluate(() => {
        window.scrollTo(0, document.body.scrollHeight / 2);
      });
      
      await page.waitForTimeout(100);
      
      // Scroll back to top
      await page.evaluate(() => {
        window.scrollTo(0, 0);
      });
      
      // Page should remain responsive
      const heading = page.locator('h1, h2');
      await expect(heading).toBeVisible();
    }
  });
});
