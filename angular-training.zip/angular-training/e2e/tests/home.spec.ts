import { test, expect, Page } from '@playwright/test';

/**
 * END-TO-END TESTING CONCEPTS FOR HOME PAGE:
 * 
 * 1. Landing Page Testing - Testing the main entry point of the application
 * 2. Navigation Testing - Testing all navigation links and user journeys
 * 3. First Impression Testing - Testing initial page load and visual appeal
 * 4. Feature Discovery Testing - Testing how users discover available features
 * 5. Call-to-Action Testing - Testing feature links and conversion funnels
 * 6. SEO and Meta Testing - Testing page titles, descriptions, and structure
 * 7. Performance Testing - Testing Core Web Vitals and load times
 * 8. Accessibility Testing - Testing screen reader navigation and keyboard access
 * 9. Mobile Experience Testing - Testing responsive design and touch interactions
 * 10. Cross-Browser Testing - Testing consistency across different browsers
 */

/**
 * PAGE OBJECT MODEL FOR HOME PAGE
 * 
 * Encapsulates home page interactions and selectors for maintainable tests
 */
class HomePage {
  constructor(private page: Page) {}

  // Navigation
  async goto() {
    await this.page.goto('/');
    await this.waitForPageLoad();
  }

  async waitForPageLoad() {
    // Wait for the main content to load
    await this.page.waitForSelector('h1', { timeout: 10000 });
    await this.page.waitForLoadState('networkidle');
  }

  // Content getters
  async getMainHeading() {
    return await this.page.locator('h1').textContent();
  }

  async getHeroDescription() {
    return await this.page.locator('.hero p, .hero-description, .welcome-text').textContent();
  }

  async getFeatureCards() {
    return this.page.locator('.feature-card, .nav-card, .section-card, .card');
  }

  async getFeatureCardCount() {
    return await (await this.getFeatureCards()).count();
  }

  async getFeatureCardInfo(index: number) {
    const cards = await this.getFeatureCards();
    const card = cards.nth(index);
    const icon = await card.locator('.feature-icon, .icon').textContent();
    const title = await card.locator('h3, .feature-title, .title').textContent();
    const description = await card.locator('p, .feature-description, .description').textContent();
    const link = card.locator('a, .feature-link, .link');
    const linkText = await link.textContent();
    const href = await link.getAttribute('href');
    
    return { icon, title, description, linkText, href };
  }

  // Navigation actions
  async clickFeatureCard(index: number) {
    const cards = await this.getFeatureCards();
    await cards.nth(index).click();
  }

  async clickFeatureLink(index: number) {
    const cards = await this.getFeatureCards();
    const card = cards.nth(index);
    const link = card.locator('a, .feature-link, .link');
    await link.click();
  }

  async navigateToUsers() {
    await this.page.click('a[href*="users"], a:has-text("Users"), a:has-text("User Management")');
  }

  async navigateToDashboard() {
    await this.page.click('a[href*="dashboard"], a:has-text("Dashboard")');
  }

  async navigateToTemplateforms() {
    await this.page.click('a[href*="template-forms"], a:has-text("Template Forms")');
  }

  async navigateToReactiveForms() {
    await this.page.click('a[href*="reactive-forms"], a:has-text("Reactive Forms")');
  }

  async navigateToSettings() {
    await this.page.click('a[href*="settings"], a:has-text("Settings")');
  }

  // Accessibility helpers
  async navigateWithKeyboard() {
    await this.page.keyboard.press('Tab');
    return await this.page.locator(':focus').textContent();
  }

  async getAllFocusableElements() {
    return this.page.locator('a, button, [tabindex]:not([tabindex="-1"])');
  }

  // Performance helpers
  async measurePageLoadTime() {
    const startTime = Date.now();
    await this.goto();
    return Date.now() - startTime;
  }
}

/**
 * HOME PAGE E2E TEST SUITE
 */
test.describe('Home Page - E2E Tests', () => {
  let homePage: HomePage;

  test.beforeEach(async ({ page }) => {
    homePage = new HomePage(page);
    await homePage.goto();
  });

  /**
   * BASIC PAGE FUNCTIONALITY TESTS
   * Testing core page loading and content display
   */
  test.describe('Page Loading and Content', () => {
    test('should load home page successfully', async ({ page }) => {
      await expect(page).toHaveTitle(/Angular Training/);
      
      const heading = await homePage.getMainHeading();
      expect(heading).toContain('Angular Training');
    });

    test('should display hero section with compelling copy', async () => {
      const heading = await homePage.getMainHeading();
      const description = await homePage.getHeroDescription();
      
      expect(heading).toBeTruthy();
      expect(heading).toContain('Angular Training');
      
      expect(description).toBeTruthy();
      expect(description?.toLowerCase()).toContain('comprehensive');
    });

    test('should display feature cards', async () => {
      const featureCardCount = await homePage.getFeatureCardCount();
      expect(featureCardCount).toBeGreaterThanOrEqual(4);
      
      // Verify first feature card has complete information
      const firstFeatureInfo = await homePage.getFeatureCardInfo(0);
      expect(firstFeatureInfo.title).toBeTruthy();
      expect(firstFeatureInfo.description).toBeTruthy();
      expect(firstFeatureInfo.href).toBeTruthy();
    });

    test('should have proper page structure', async ({ page }) => {
      // Check for semantic HTML structure
      await expect(page.locator('h1')).toBeVisible();
      await expect(page.locator('main, [role="main"], .main-content')).toBeVisible();
      
      // Check for navigation elements
      const links = page.locator('a[href]');
      const linkCount = await links.count();
      expect(linkCount).toBeGreaterThan(0);
    });
  });

  /**
   * FEATURE DISCOVERY TESTS
   * Testing how users discover and understand available features
   */
  test.describe('Feature Discovery', () => {
    test('should showcase User Management feature', async () => {
      const featureCards = await homePage.getFeatureCards();
      const cardCount = await featureCards.count();
      
      let userMgmtFound = false;
      for (let i = 0; i < cardCount; i++) {
        const cardInfo = await homePage.getFeatureCardInfo(i);
        if (cardInfo.title?.toLowerCase().includes('user')) {
          expect(cardInfo.description?.toLowerCase()).toContain('manage');
          expect(cardInfo.href).toContain('users');
          userMgmtFound = true;
          break;
        }
      }
      expect(userMgmtFound).toBeTruthy();
    });

    test('should showcase Search functionality', async () => {
      const featureCards = await homePage.getFeatureCards();
      const cardCount = await featureCards.count();
      
      let searchFound = false;
      for (let i = 0; i < cardCount; i++) {
        const cardInfo = await homePage.getFeatureCardInfo(i);
        if (cardInfo.title?.toLowerCase().includes('search')) {
          expect(cardInfo.description?.toLowerCase()).toContain('filter');
          searchFound = true;
          break;
        }
      }
      expect(searchFound).toBeTruthy();
    });

    test('should showcase Dashboard feature', async () => {
      const featureCards = await homePage.getFeatureCards();
      const cardCount = await featureCards.count();
      
      let dashboardFound = false;
      for (let i = 0; i < cardCount; i++) {
        const cardInfo = await homePage.getFeatureCardInfo(i);
        if (cardInfo.title?.toLowerCase().includes('dashboard')) {
          expect(cardInfo.description?.toLowerCase()).toContain('analytics');
          expect(cardInfo.href).toContain('dashboard');
          dashboardFound = true;
          break;
        }
      }
      expect(dashboardFound).toBeTruthy();
    });

    test('should showcase Forms features', async () => {
      const featureCards = await homePage.getFeatureCards();
      const cardCount = await featureCards.count();
      
      let templateFormsFound = false;
      let reactiveFormsFound = false;
      
      for (let i = 0; i < cardCount; i++) {
        const cardInfo = await homePage.getFeatureCardInfo(i);
        const title = cardInfo.title?.toLowerCase() || '';
        
        if (title.includes('template') && title.includes('form')) {
          expect(cardInfo.description?.toLowerCase()).toContain('validation');
          expect(cardInfo.href).toContain('template-forms');
          templateFormsFound = true;
        }
        
        if (title.includes('reactive') && title.includes('form')) {
          expect(cardInfo.description?.toLowerCase()).toContain('reactive');
          expect(cardInfo.href).toContain('reactive-forms');
          reactiveFormsFound = true;
        }
      }
      
      expect(templateFormsFound).toBeTruthy();
      expect(reactiveFormsFound).toBeTruthy();
    });

    test('should have meaningful feature icons', async () => {
      const featureCards = await homePage.getFeatureCards();
      const cardCount = await featureCards.count();
      
      for (let i = 0; i < cardCount; i++) {
        const cardInfo = await homePage.getFeatureCardInfo(i);
        expect(cardInfo.icon?.trim()).toBeTruthy();
        expect(cardInfo.icon?.length).toBeGreaterThan(0);
      }
    });
  });

  /**
   * NAVIGATION TESTS
   * Testing all navigation links and user journeys
   */
  test.describe('Navigation', () => {
    test('should navigate to Users page', async ({ page }) => {
      await homePage.navigateToUsers();
      await page.waitForURL('**/users**', { timeout: 5000 });
      expect(page.url()).toContain('/users');
      
      // Verify we landed on the correct page
      await expect(page.locator('h1')).toContainText(/Users/i);
    });

    test('should navigate to Dashboard page', async ({ page }) => {
      await homePage.navigateToDashboard();
      await page.waitForURL('**/dashboard**', { timeout: 5000 });
      expect(page.url()).toContain('/dashboard');
    });

    test('should navigate to Template Forms page', async ({ page }) => {
      await homePage.navigateToTemplateforms();
      await page.waitForURL('**/template-forms**', { timeout: 5000 });
      expect(page.url()).toContain('/template-forms');
      
      await expect(page.locator('h1')).toContainText(/Template/i);
    });

    test('should navigate to Reactive Forms page', async ({ page }) => {
      await homePage.navigateToReactiveForms();
      await page.waitForURL('**/reactive-forms**', { timeout: 5000 });
      expect(page.url()).toContain('/reactive-forms');
      
      await expect(page.locator('h1')).toContainText(/Reactive/i);
    });

    test('should navigate to Settings page', async ({ page }) => {
      await homePage.navigateToSettings();
      await page.waitForURL('**/settings**', { timeout: 5000 });
      expect(page.url()).toContain('/settings');
    });

    test('should maintain navigation state across browser actions', async ({ page }) => {
      // Navigate to a feature page
      await homePage.navigateToUsers();
      await page.waitForURL('**/users**');
      
      // Go back to home
      await page.goBack();
      await page.waitForURL('/');
      
      // Verify we're back on home page
      const heading = await homePage.getMainHeading();
      expect(heading).toContain('Angular Training');
      
      // Go forward again
      await page.goForward();
      await page.waitForURL('**/users**');
      expect(page.url()).toContain('/users');
    });
  });

  /**
   * RESPONSIVE DESIGN TESTS
   * Testing mobile and tablet layouts
   */
  test.describe('Responsive Design', () => {
    test('should display correctly on mobile devices', async ({ page }) => {
      await page.setViewportSize({ width: 375, height: 667 });
      await homePage.goto();
      
      // Main heading should be visible
      await expect(page.locator('h1')).toBeVisible();
      
      // Feature cards should stack vertically
      const featureCards = await homePage.getFeatureCards();
      const cardCount = await featureCards.count();
      
      if (cardCount >= 2) {
        const firstCardBox = await featureCards.nth(0).boundingBox();
        const secondCardBox = await featureCards.nth(1).boundingBox();
        
        // On mobile, cards should stack vertically
        expect(secondCardBox?.y).toBeGreaterThan(firstCardBox?.y || 0);
      }
    });

    test('should display correctly on tablet devices', async ({ page }) => {
      await page.setViewportSize({ width: 768, height: 1024 });
      await homePage.goto();
      
      // All content should be visible and accessible
      await expect(page.locator('h1')).toBeVisible();
      
      const featureCards = await homePage.getFeatureCards();
      await expect(featureCards.first()).toBeVisible();
    });

    test('should adapt layout for desktop screens', async ({ page }) => {
      await page.setViewportSize({ width: 1200, height: 800 });
      await homePage.goto();
      
      // Desktop should show cards in a grid layout
      const featureCards = await homePage.getFeatureCards();
      const cardCount = await featureCards.count();
      
      if (cardCount >= 4) {
        // On desktop, some cards should be side by side
        const firstCardBox = await featureCards.nth(0).boundingBox();
        const secondCardBox = await featureCards.nth(1).boundingBox();
        
        // Cards might be side by side (same row) or stacked
        expect(firstCardBox?.x).toBeDefined();
        expect(secondCardBox?.x).toBeDefined();
      }
    });

    test('should maintain functionality across screen sizes', async ({ page }) => {
      const viewports = [
        { width: 320, height: 568 }, // iPhone SE
        { width: 768, height: 1024 }, // iPad
        { width: 1024, height: 768 }, // Desktop small
        { width: 1920, height: 1080 }  // Desktop large
      ];
      
      for (const viewport of viewports) {
        await page.setViewportSize(viewport);
        await homePage.goto();
        
        // Core functionality should work on all screen sizes
        await expect(page.locator('h1')).toBeVisible();
        const featureCardCount = await homePage.getFeatureCardCount();
        expect(featureCardCount).toBeGreaterThan(0);
        
        // Navigation should work
        const featureCards = await homePage.getFeatureCards();
        const firstFeatureCard = featureCards.first();
        await expect(firstFeatureCard).toBeVisible();
      }
    });
  });

  /**
   * ACCESSIBILITY TESTS
   * Testing keyboard navigation and screen reader support
   */
  test.describe('Accessibility', () => {
    test('should support keyboard navigation', async ({ page }) => {
      // Tab through focusable elements
      await page.keyboard.press('Tab');
      const firstFocused = await page.locator(':focus');
      await expect(firstFocused).toBeVisible();
      
      // Continue tabbing to ensure all links are reachable
      for (let i = 0; i < 5; i++) {
        await page.keyboard.press('Tab');
        const focused = await page.locator(':focus');
        await expect(focused).toBeVisible();
      }
    });

    test('should have proper ARIA structure', async ({ page }) => {
      // Check for proper heading hierarchy
      const h1Elements = page.locator('h1');
      expect(await h1Elements.count()).toBe(1);
      
      // Check for semantic landmarks
      const main = page.locator('main, [role="main"]');
      await expect(main).toBeVisible();
      
      // Check that links have accessible names
      const links = page.locator('a');
      const linkCount = await links.count();
      
      for (let i = 0; i < Math.min(linkCount, 10); i++) {
        const link = links.nth(i);
        const accessibleName = 
          (await link.textContent()) ||
          (await link.getAttribute('aria-label')) ||
          (await link.getAttribute('title'));
        
        expect(accessibleName?.trim()).toBeTruthy();
      }
    });

    test('should have sufficient color contrast', async ({ page }) => {
      // This is a placeholder for color contrast testing
      // In a real implementation, you would use tools like axe-playwright
      
      // Verify text elements are visible (basic check)
      await expect(page.locator('h1')).toBeVisible();
      await expect(page.locator('p')).toBeVisible();
      
      // Verify links are distinguishable
      const links = page.locator('a');
      await expect(links.first()).toBeVisible();
    });

    test('should work with screen readers', async ({ page }) => {
      // Check for alt text on images (if any)
      const images = page.locator('img');
      const imageCount = await images.count();
      
      for (let i = 0; i < imageCount; i++) {
        const img = images.nth(i);
        const alt = await img.getAttribute('alt');
        const ariaLabel = await img.getAttribute('aria-label');
        
        expect(alt || ariaLabel).toBeTruthy();
      }
      
      // Check for descriptive link text
      const featureCards = await homePage.getFeatureCards();
      const cardCount = await featureCards.count();
      
      for (let i = 0; i < cardCount; i++) {
        const cardInfo = await homePage.getFeatureCardInfo(i);
        expect(cardInfo.linkText?.toLowerCase()).toMatch(/view|try|open|explore|learn/);
      }
    });
  });

  /**
   * PERFORMANCE TESTS
   * Testing page load times and Core Web Vitals
   */
  test.describe('Performance', () => {
    test('should load within acceptable time', async () => {
      const loadTime = await homePage.measurePageLoadTime();
      
      // Page should load within 3 seconds
      expect(loadTime).toBeLessThan(3000);
    });

    test('should have fast first contentful paint', async ({ page }) => {
      const startTime = Date.now();
      
      await homePage.goto();
      
      // Wait for first meaningful content
      await expect(page.locator('h1')).toBeVisible();
      
      const fcp = Date.now() - startTime;
      
      // First Contentful Paint should be under 2 seconds
      expect(fcp).toBeLessThan(2000);
    });

    test('should be interactive quickly', async ({ page }) => {
      await homePage.goto();
      
      // Test that interactions work immediately after load
      const featureCards = await homePage.getFeatureCards();
      const firstFeatureCard = featureCards.first();
      
      // Should be able to interact with elements
      await expect(firstFeatureCard).toBeVisible();
      await firstFeatureCard.hover();
      
      // Click should work
      await firstFeatureCard.click();
      
      // Should navigate (indicating page is interactive)
      await page.waitForURL(/\/(users|dashboard|template-forms|reactive-forms|settings)/);
    });

    test('should handle rapid navigation', async ({ page }) => {
      // Test rapid back and forth navigation
      await homePage.navigateToUsers();
      await page.waitForURL('**/users**');
      
      await page.goBack();
      await page.waitForURL('/');
      
      await homePage.navigateToDashboard();
      await page.waitForURL('**/dashboard**');
      
      await page.goBack();
      await page.waitForURL('/');
      
      // Page should still be functional
      const heading = await homePage.getMainHeading();
      expect(heading).toContain('Angular Training');
    });
  });

  /**
   * SEO AND META TESTS
   * Testing search engine optimization elements
   */
  test.describe('SEO and Meta Information', () => {
    test('should have proper page title', async ({ page }) => {
      const title = await page.title();
      expect(title).toBeTruthy();
      expect(title.toLowerCase()).toContain('angular');
    });

    test('should have meta description', async ({ page }) => {
      const metaDescription = await page.getAttribute('meta[name="description"]', 'content');
      
      if (metaDescription) {
        expect(metaDescription.length).toBeGreaterThan(50);
        expect(metaDescription.length).toBeLessThan(160);
      }
    });

    test('should have proper heading structure for SEO', async ({ page }) => {
      // Should have exactly one H1
      const h1Count = await page.locator('h1').count();
      expect(h1Count).toBe(1);
      
      // Should have H2 or H3 elements for content hierarchy
      const h2Count = await page.locator('h2').count();
      const h3Count = await page.locator('h3').count();
      expect(h2Count + h3Count).toBeGreaterThan(0);
    });

    test('should have clean URLs', async ({ page }) => {
      expect(page.url()).toMatch(/.*\/$/); // Should end with / for home page
      expect(page.url()).not.toContain('#'); // Should not have hash fragments
      expect(page.url()).not.toContain('?'); // Should not have query parameters
    });
  });

  /**
   * CONTENT QUALITY TESTS
   * Testing content clarity and user experience
   */
  test.describe('Content Quality', () => {
    test('should have clear value proposition', async () => {
      const heading = await homePage.getMainHeading();
      const description = await homePage.getHeroDescription();
      
      // Heading should be compelling
      expect(heading).toBeTruthy();
      expect(heading?.length).toBeGreaterThan(10);
      
      // Description should explain the value
      expect(description).toBeTruthy();
      expect(description?.toLowerCase()).toMatch(/comprehensive|sample|demonstrating|features|learn/);
    });

    test('should have actionable call-to-actions', async () => {
      const featureCards = await homePage.getFeatureCards();
      const cardCount = await featureCards.count();
      
      for (let i = 0; i < cardCount; i++) {
        const cardInfo = await homePage.getFeatureCardInfo(i);
        
        // Links should have action-oriented text
        expect(cardInfo.linkText?.toLowerCase()).toMatch(/view|try|open|explore|learn|go to/);
      }
    });

    test('should have consistent feature descriptions', async () => {
      const featureCards = await homePage.getFeatureCards();
      const cardCount = await featureCards.count();
      
      for (let i = 0; i < cardCount; i++) {
        const cardInfo = await homePage.getFeatureCardInfo(i);
        
        // Each feature should have title, description, and link
        expect(cardInfo.title).toBeTruthy();
        expect(cardInfo.description).toBeTruthy();
        expect(cardInfo.linkText).toBeTruthy();
        expect(cardInfo.href).toBeTruthy();
        
        // Descriptions should be substantial
        expect(cardInfo.description?.length).toBeGreaterThan(20);
      }
    });
  });
});
