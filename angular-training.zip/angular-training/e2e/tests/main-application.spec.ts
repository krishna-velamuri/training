import { test, expect, Page } from '@playwright/test';

/**
 * End-to-End tests for the Angular Training Application
 * 
 * This test suite demonstrates comprehensive e2e testing concepts:
 * 1. Testing application navigation and routing
 * 2. Testing user interface interactions across pages
 * 3. Testing responsive design on different screen sizes
 * 4. Testing accessibility features
 * 5. Testing performance and loading times
 * 6. Testing browser compatibility scenarios
 * 7. Testing error handling and edge cases
 */

// Test configuration and setup
test.describe('Angular Training Application - Main Flow', () => {
  let page: Page;

  /**
   * Setup hook that runs before each test
   * This demonstrates proper test setup and navigation
   */
  test.beforeEach(async ({ page: testPage }) => {
    page = testPage;
    
    // Navigate to the application home page
    await page.goto('/');
    
    // Wait for the application to load completely
    await page.waitForLoadState('networkidle');
  });

  /**
   * Test home page loading and basic structure
   * This verifies the application loads correctly and displays expected content
   */
  test('should load home page correctly', async () => {
    // Check that the page title is set correctly
    await expect(page).toHaveTitle(/Angular Training/i);
    
    // Verify main heading is visible
    const mainHeading = page.locator('h1').first();
    await expect(mainHeading).toBeVisible();
    await expect(mainHeading).toContainText(/Angular Training/i);
    
    // Check that navigation is present
    const navigation = page.locator('nav, .navbar, .navigation');
    await expect(navigation).toBeVisible();
    
    // Verify key navigation links are present
    await expect(page.locator('a[routerLink="/users"]')).toBeVisible();
    await expect(page.locator('a[routerLink="/dashboard"]')).toBeVisible();
    await expect(page.locator('a[routerLink="/template-forms"]')).toBeVisible();
    await expect(page.locator('a[routerLink="/reactive-forms"]')).toBeVisible();
  });

  /**
   * Test navigation between pages
   * This demonstrates testing routing and page transitions
   */
  test('should navigate between pages correctly', async () => {
    // Test navigation to Users page
    await page.click('a[routerLink="/users"]');
    await page.waitForURL('**/users');
    await expect(page.locator('h1, h2')).toContainText(/Users/i);
    
    // Test navigation to Dashboard
    await page.click('a[routerLink="/dashboard"]');
    await page.waitForURL('**/dashboard');
    await expect(page.locator('h1, h2')).toContainText(/Dashboard/i);
    
    // Test navigation to Template Forms
    await page.click('a[routerLink="/template-forms"]');
    await page.waitForURL('**/template-forms');
    await expect(page.locator('h1, h2')).toContainText(/Template.*Forms/i);
    
    // Test navigation to Reactive Forms
    await page.click('a[routerLink="/reactive-forms"]');
    await page.waitForURL('**/reactive-forms');
    await expect(page.locator('h1, h2')).toContainText(/Reactive.*Forms/i);
    
    // Test navigation back to home
    await page.click('a[routerLink="/"]');
    await page.waitForURL('/');
    await expect(page.locator('h1')).toContainText(/Angular Training/i);
  });

  /**
   * Test mobile navigation functionality
   * This demonstrates testing responsive design and mobile interactions
   */
  test('should work correctly on mobile devices', async () => {
    // Set mobile viewport
    await page.setViewportSize({ width: 375, height: 667 });
    
    // Check if mobile menu toggle is visible
    const mobileToggle = page.locator('.mobile-toggle, .nav-toggle, .hamburger');
    if (await mobileToggle.isVisible()) {
      // Test mobile menu functionality
      await mobileToggle.click();
      
      // Verify mobile menu opens
      const mobileMenu = page.locator('.nav-menu.active, .mobile-menu.open, .nav-menu.nav-menu-active');
      await expect(mobileMenu).toBeVisible();
      
      // Test navigation in mobile menu
      await page.click('a[routerLink="/users"]');
      await page.waitForURL('**/users');
      await expect(page.locator('h1, h2')).toContainText(/Users/i);
    }
    
    // Test that content is properly responsive
    const mainContent = page.locator('main, .main-content, .content');
    await expect(mainContent).toBeVisible();
    
    // Verify no horizontal scrolling is needed
    const bodyScrollWidth = await page.evaluate(() => document.body.scrollWidth);
    const viewportWidth = await page.evaluate(() => window.innerWidth);
    expect(bodyScrollWidth).toBeLessThanOrEqual(viewportWidth + 5); // Small tolerance for rounding
  });

  /**
   * Test application performance
   * This demonstrates basic performance testing in e2e tests
   */
  test('should load pages within reasonable time', async () => {
    const pages = ['/users', '/dashboard', '/template-forms', '/reactive-forms'];
    
    for (const pagePath of pages) {
      const startTime = Date.now();
      
      await page.goto(pagePath);
      await page.waitForLoadState('networkidle');
      
      const loadTime = Date.now() - startTime;
      
      // Pages should load within 3 seconds
      expect(loadTime).toBeLessThan(3000);
      
      // Verify page content is visible
      const pageContent = page.locator('main, .content, .page-content');
      await expect(pageContent).toBeVisible();
    }
  });

  /**
   * Test accessibility features
   * This demonstrates testing for accessibility compliance
   */
  test('should meet basic accessibility requirements', async () => {
    // Test keyboard navigation
    await page.keyboard.press('Tab');
    
    // Check that focus is visible on interactive elements
    const focusedElement = page.locator(':focus');
    await expect(focusedElement).toBeVisible();
    
    // Test navigation with keyboard
    await page.keyboard.press('Enter');
    
    // Verify headings hierarchy (should have h1)
    const h1Elements = page.locator('h1');
    await expect(h1Elements).toHaveCount(1);
    
    // Check for proper link text (should not be generic)
    const links = page.locator('a[routerLink]');
    const linkCount = await links.count();
    
    for (let i = 0; i < linkCount; i++) {
      const linkText = await links.nth(i).textContent();
      expect(linkText).toBeTruthy();
      expect(linkText?.trim().length).toBeGreaterThan(0);
      // Links should not be generic like "click here" or "read more"
      expect(linkText?.toLowerCase()).not.toMatch(/^(click here|read more|link|more)$/);
    }
    
    // Check for proper alt text on images (if any)
    const images = page.locator('img');
    const imageCount = await images.count();
    
    for (let i = 0; i < imageCount; i++) {
      const altText = await images.nth(i).getAttribute('alt');
      if (altText !== null) {
        expect(altText.length).toBeGreaterThan(0);
      }
    }
  });

  /**
   * Test error handling
   * This demonstrates testing application robustness
   */
  test('should handle invalid routes gracefully', async () => {
    // Navigate to a non-existent route
    await page.goto('/non-existent-page');
    
    // Should either redirect to home or show a 404 page
    // Wait a moment for any redirects
    await page.waitForTimeout(1000);
    
    const currentUrl = page.url();
    const pageContent = await page.textContent('body');
    
    // Should either be redirected to home or show error page
    expect(
      currentUrl.endsWith('/') || 
      pageContent?.includes('404') || 
      pageContent?.includes('Not Found') ||
      pageContent?.includes('Page not found')
    ).toBeTruthy();
  });

  /**
   * Test cross-browser compatibility scenarios
   * This test checks for common cross-browser issues
   */
  test('should work consistently across page reloads', async () => {
    // Navigate to a page
    await page.click('a[routerLink="/users"]');
    await page.waitForURL('**/users');
    
    // Reload the page
    await page.reload();
    await page.waitForLoadState('networkidle');
    
    // Verify page still works correctly
    await expect(page.locator('h1, h2')).toContainText(/Users/i);
    
    // Test navigation still works after reload
    await page.click('a[routerLink="/dashboard"]');
    await page.waitForURL('**/dashboard');
    await expect(page.locator('h1, h2')).toContainText(/Dashboard/i);
  });

  /**
   * Test responsive design on different screen sizes
   * This demonstrates testing responsive behavior
   */
  test('should be responsive on different screen sizes', async () => {
    const viewports = [
      { width: 320, height: 568, name: 'Mobile (iPhone SE)' },
      { width: 768, height: 1024, name: 'Tablet' },
      { width: 1024, height: 768, name: 'Desktop Small' },
      { width: 1920, height: 1080, name: 'Desktop Large' }
    ];
    
    for (const viewport of viewports) {
      await page.setViewportSize({ width: viewport.width, height: viewport.height });
      
      // Verify main content is visible
      const mainContent = page.locator('main, .content, .page-content');
      await expect(mainContent).toBeVisible();
      
      // Verify navigation is accessible (either visible or via mobile menu)
      const navLinks = page.locator('a[routerLink]');
      const visibleNavLinks = await navLinks.filter({ hasText: /Users|Dashboard|Forms/ }).count();
      
      if (visibleNavLinks === 0) {
        // Check for mobile menu toggle
        const mobileToggle = page.locator('.mobile-toggle, .nav-toggle, .hamburger');
        if (await mobileToggle.isVisible()) {
          await mobileToggle.click();
          const mobileNavLinks = await navLinks.filter({ hasText: /Users|Dashboard|Forms/ }).count();
          expect(mobileNavLinks).toBeGreaterThan(0);
        }
      } else {
        expect(visibleNavLinks).toBeGreaterThan(0);
      }
    }
  });

  /**
   * Test user journey: Complete application walkthrough
   * This demonstrates testing a complete user workflow
   */
  test('should support complete user journey', async () => {
    // Start at home page
    await expect(page.locator('h1')).toContainText(/Angular Training/i);
    
    // Explore Users section
    await page.click('a[routerLink="/users"]');
    await page.waitForURL('**/users');
    await expect(page.locator('h1, h2')).toContainText(/Users/i);
    
    // Check if user list is displayed
    const userList = page.locator('.user-list, .users-grid, .user-card, table, .list-item');
    if (await userList.first().isVisible()) {
      // If users are displayed, verify they have proper content
      const userItems = userList.locator('.user-item, .user-card, tr, .list-item').first();
      if (await userItems.isVisible()) {
        await expect(userItems).toContainText(/.+/); // Should have some content
      }
    }
    
    // Visit Dashboard
    await page.click('a[routerLink="/dashboard"]');
    await page.waitForURL('**/dashboard');
    await expect(page.locator('h1, h2')).toContainText(/Dashboard/i);
    
    // Check dashboard content
    const dashboardContent = page.locator('.dashboard-content, .stats, .metrics, .chart');
    // Dashboard should have some content or placeholder
    const bodyText = await page.textContent('body');
    expect(bodyText).toBeTruthy();
    expect(bodyText!.length).toBeGreaterThan(50);
    
    // Explore Template Forms
    await page.click('a[routerLink="/template-forms"]');
    await page.waitForURL('**/template-forms');
    await expect(page.locator('h1, h2')).toContainText(/Template.*Forms/i);
    
    // Verify form elements are present
    const formElements = page.locator('form, input, select, textarea');
    await expect(formElements.first()).toBeVisible();
    
    // Explore Reactive Forms
    await page.click('a[routerLink="/reactive-forms"]');
    await page.waitForURL('**/reactive-forms');
    await expect(page.locator('h1, h2')).toContainText(/Reactive.*Forms/i);
    
    // Verify reactive form elements are present
    const reactiveFormElements = page.locator('form, input, select, textarea');
    await expect(reactiveFormElements.first()).toBeVisible();
    
    // Return to home
    await page.click('a[routerLink="/"]');
    await page.waitForURL('/');
    await expect(page.locator('h1')).toContainText(/Angular Training/i);
  });

  /**
   * Test application state persistence
   * This demonstrates testing that application state is maintained correctly
   */
  test('should maintain navigation state correctly', async () => {
    // Navigate through several pages
    await page.click('a[routerLink="/users"]');
    await page.waitForURL('**/users');
    
    // Use browser back button
    await page.goBack();
    await expect(page).toHaveURL('/');
    
    // Use browser forward button
    await page.goForward();
    await expect(page).toHaveURL(/.*\/users/);
    
    // Navigate to another page
    await page.click('a[routerLink="/dashboard"]');
    await page.waitForURL('**/dashboard');
    
    // Verify browser history works correctly
    await page.goBack();
    await expect(page).toHaveURL(/.*\/users/);
    
    await page.goBack();
    await expect(page).toHaveURL('/');
  });
});
