import { test, expect, Page } from '@playwright/test';

/**
 * END-TO-END TESTING FOR REACTIVE FORMS
 * 
 * This test suite demonstrates advanced e2e testing concepts for reactive forms:
 * 1. Tab-based Navigation Testing
 * 2. Dynamic Form Controls Testing (Skills Array)
 * 3. Real-time Validation Testing
 * 4. Cross-field Validation Testing (Password Confirmation)
 * 5. Async Validation Testing (Username/Email availability)
 * 6. Complex Form State Management Testing
 */

class ReactiveFormsPage {
  constructor(private page: Page) {}

  async goto() {
    await this.page.goto('/reactive-forms');
  }

  // Tab navigation
  async switchToTab(tabIndex: number) {
    const tabs = this.page.locator('.tab-button');
    await tabs.nth(tabIndex).click();
  }

  async getCurrentTab() {
    const activeTab = await this.page.locator('.tab-button.active').textContent();
    return activeTab?.trim() || '';
  }

  // Form filling methods for different tabs
  async fillBasicInfo(data: {
    username: string;
    email: string;
    firstName: string;
    lastName: string;
    dateOfBirth: string;
    phone: string;
  }) {
    await this.page.fill('#username', data.username);
    await this.page.fill('#email', data.email);
    await this.page.fill('#firstName', data.firstName);
    await this.page.fill('#lastName', data.lastName);
    await this.page.fill('#dateOfBirth', data.dateOfBirth);
    await this.page.fill('#phone', data.phone);
  }

  async fillProfessionalInfo(data: {
    company: string;
    position: string;
    experience: string;
    salary?: string;
    website?: string;
  }) {
    await this.page.fill('#company', data.company);
    await this.page.fill('#position', data.position);
    await this.page.fill('#experience', data.experience);
    
    if (data.salary) {
      await this.page.fill('#salary', data.salary);
    }
    
    if (data.website) {
      await this.page.fill('#website', data.website);
    }
  }

  async addSkill(skill: string) {
    // Add new skill input
    await this.page.click('button:has-text("Add Skill")');
    
    // Fill the last skill input
    const skillInputs = this.page.locator('.skill-input');
    const lastInput = skillInputs.last();
    await lastInput.fill(skill);
  }

  async removeSkill(index: number) {
    const removeButtons = this.page.locator('button:has-text("Remove")');
    await removeButtons.nth(index).click();
  }

  async getSkillsCount() {
    return await this.page.locator('.skill-input').count();
  }

  async fillSecurityAndPreferences(data: {
    password: string;
    confirmPassword: string;
    country: string;
    emailNotifications?: boolean;
    smsNotifications?: boolean;
    agreeToTerms: boolean;
  }) {
    await this.page.fill('#password', data.password);
    await this.page.fill('#confirmPassword', data.confirmPassword);
    await this.page.selectOption('#country', data.country);
    
    if (data.emailNotifications) {
      await this.page.check('input[formControlName="emailNotifications"]');
    }
    
    if (data.smsNotifications) {
      await this.page.check('input[formControlName="smsNotifications"]');
    }
    
    if (data.agreeToTerms) {
      await this.page.check('input[formControlName="agreeToTerms"]');
    }
  }

  // Validation and status checking
  async hasValidationError(message: string) {
    return await this.page.locator('.error-messages small', { hasText: message }).isVisible();
  }

  async isFieldPending(fieldId: string) {
    return await this.page.locator(`#${fieldId}.pending`).isVisible();
  }

  async hasPasswordStrengthIndicator() {
    return await this.page.locator('.password-strength').isVisible();
  }

  async getPasswordStrengthItems() {
    return await this.page.locator('.strength-item').allTextContents();
  }

  async isTabValid(tabIndex: number) {
    const tabs = this.page.locator('.tab-button');
    const tabBadge = tabs.nth(tabIndex).locator('.tab-badge.success');
    return await tabBadge.isVisible();
  }

  async hasTabErrors(tabIndex: number) {
    const tabs = this.page.locator('.tab-button');
    const tabBadge = tabs.nth(tabIndex).locator('.tab-badge.error');
    return await tabBadge.isVisible();
  }

  async submitForm() {
    await this.page.click('button:has-text("Submit")');
  }

  async resetForm() {
    await this.page.click('button:has-text("Reset Form")');
  }

  async toggleDebugInfo() {
    await this.page.click('button:has-text("Show Debug Info"), button:has-text("Hide Debug Info")');
  }

  async isDebugInfoVisible() {
    return await this.page.locator('.debug-info').isVisible();
  }
}

test.describe('Reactive Forms - E2E Tests', () => {
  let page: Page;
  let reactiveFormsPage: ReactiveFormsPage;

  const validUserData = {
    basic: {
      username: 'testuser123',
      email: 'test@example.com',
      firstName: 'John',
      lastName: 'Doe',
      dateOfBirth: '1990-01-01',
      phone: '5551234567'
    },
    professional: {
      company: 'Tech Solutions Inc',
      position: 'Senior Developer',
      experience: '7',
      salary: '95000',
      website: 'https://johndoe.dev'
    },
    security: {
      password: 'SecurePass123!',
      confirmPassword: 'SecurePass123!',
      country: 'United States',
      emailNotifications: true,
      smsNotifications: false,
      agreeToTerms: true
    },
    skills: ['JavaScript', 'Angular', 'TypeScript', 'Node.js']
  };

  test.beforeEach(async ({ page: testPage }: { page: Page }) => {
    page = testPage;
    reactiveFormsPage = new ReactiveFormsPage(page);
    await reactiveFormsPage.goto();
  });

  /**
   * TAB NAVIGATION TESTS
   */
  test.describe('Tab Navigation', () => {
    test('should display all form tabs', async () => {
      const tabs = page.locator('.tab-button');
      await expect(tabs).toHaveCount(3);
      
      const tabTexts = await tabs.allTextContents();
      expect(tabTexts.map(t => t.trim())).toEqual(
        expect.arrayContaining(['Basic Info', 'Professional', 'Security'])
      );
    });

    test('should start with first tab active', async () => {
      const currentTab = await reactiveFormsPage.getCurrentTab();
      expect(currentTab).toContain('Basic Info');
    });

    test('should switch between tabs', async () => {
      // Switch to Professional tab
      await reactiveFormsPage.switchToTab(1);
      const professionalTab = await reactiveFormsPage.getCurrentTab();
      expect(professionalTab).toContain('Professional');
      
      // Switch to Security tab
      await reactiveFormsPage.switchToTab(2);
      const securityTab = await reactiveFormsPage.getCurrentTab();
      expect(securityTab).toContain('Security');
    });

    test('should show tab validation indicators', async () => {
      // Initially, tabs should show errors (empty form)
      expect(await reactiveFormsPage.hasTabErrors(0)).toBe(true);
      
      // Fill basic info to make tab valid
      await reactiveFormsPage.fillBasicInfo(validUserData.basic);
      
      // Wait for validation and check if tab becomes valid
      await page.waitForTimeout(1000); // Allow for async validation
      expect(await reactiveFormsPage.isTabValid(0)).toBe(true);
    });
  });

  /**
   * FORM VALIDATION TESTS
   */
  test.describe('Form Validation', () => {
    test('should validate required fields', async () => {
      // Test username validation
      await page.click('#username');
      await page.click('#email'); // Blur from username
      
      await expect(reactiveFormsPage.hasValidationError('Username is required')).resolves.toBe(true);
    });

    test('should validate username format and length', async () => {
      // Test too short username
      await page.fill('#username', 'ab');
      await page.click('#email');
      
      await expect(reactiveFormsPage.hasValidationError('Username must be at least 3 characters')).resolves.toBe(true);
      
      // Test invalid characters
      await page.fill('#username', 'user@name');
      await page.click('#email');
      
      await expect(reactiveFormsPage.hasValidationError('Username can only contain letters, numbers, and underscores')).resolves.toBe(true);
    });

    test('should show async validation for username', async () => {
      await page.fill('#username', 'validusername');
      
      // Should show pending state during async validation
      await expect(reactiveFormsPage.isFieldPending('username')).resolves.toBe(true);
      
      // Wait for async validation to complete
      await page.waitForTimeout(1000);
      
      // Should show available message
      await expect(page.locator('.status-success')).toBeVisible();
    });

    test('should validate email format and availability', async () => {
      // Test invalid email format
      await page.fill('#email', 'invalid-email');
      await page.click('#username');
      
      await expect(reactiveFormsPage.hasValidationError('Please enter a valid email address')).resolves.toBe(true);
      
      // Test valid email format
      await page.fill('#email', 'valid@example.com');
      await page.waitForTimeout(1000); // Wait for async validation
    });

    test('should validate nested form groups', async () => {
      // Test personal info validation
      await page.fill('#firstName', 'A');
      await page.click('#lastName');
      
      await expect(reactiveFormsPage.hasValidationError('First name must be at least 2 characters')).resolves.toBe(true);
    });

    test('should validate number ranges', async () => {
      await reactiveFormsPage.switchToTab(1); // Professional tab
      
      // Test experience validation
      await page.fill('#experience', '-1');
      await page.click('#salary');
      
      await expect(reactiveFormsPage.hasValidationError('Experience cannot be negative')).resolves.toBe(true);
      
      await page.fill('#experience', '51');
      await page.click('#salary');
      
      await expect(reactiveFormsPage.hasValidationError('Experience cannot exceed 50 years')).resolves.toBe(true);
    });
  });

  /**
   * DYNAMIC FORM CONTROLS TESTS
   */
  test.describe('Dynamic Skills Array', () => {
    test('should start with one skill input', async () => {
      await reactiveFormsPage.switchToTab(1);
      expect(await reactiveFormsPage.getSkillsCount()).toBe(1);
    });

    test('should add new skill inputs', async () => {
      await reactiveFormsPage.switchToTab(1);
      
      await reactiveFormsPage.addSkill('JavaScript');
      expect(await reactiveFormsPage.getSkillsCount()).toBe(2);
      
      await reactiveFormsPage.addSkill('Angular');
      expect(await reactiveFormsPage.getSkillsCount()).toBe(3);
    });

    test('should remove skill inputs', async () => {
      await reactiveFormsPage.switchToTab(1);
      
      // Add skills first
      await reactiveFormsPage.addSkill('JavaScript');
      await reactiveFormsPage.addSkill('Angular');
      
      // Remove one skill
      await reactiveFormsPage.removeSkill(1);
      expect(await reactiveFormsPage.getSkillsCount()).toBe(2);
    });

    test('should not remove last skill input', async () => {
      await reactiveFormsPage.switchToTab(1);
      
      // Try to remove the only skill input
      const removeButton = page.locator('button:has-text("Remove")').first();
      expect(await removeButton.isDisabled()).toBe(true);
    });

    test('should validate minimum skills requirement', async () => {
      await reactiveFormsPage.switchToTab(1);
      
      // Fill only one skill (requirement is 3)
      const skillInput = page.locator('.skill-input').first();
      await skillInput.fill('JavaScript');
      await skillInput.blur();
      
      await expect(reactiveFormsPage.hasValidationError('Please add at least 3 skills')).resolves.toBe(true);
    });
  });

  /**
   * PASSWORD VALIDATION TESTS
   */
  test.describe('Password Validation', () => {
    test('should show password strength indicators', async () => {
      await reactiveFormsPage.switchToTab(2);
      
      await page.fill('#password', 'weak');
      
      await expect(reactiveFormsPage.hasPasswordStrengthIndicator()).resolves.toBe(true);
      
      const strengthItems = await reactiveFormsPage.getPasswordStrengthItems();
      expect(strengthItems.some(item => item.includes('Contains number'))).toBe(true);
      expect(strengthItems.some(item => item.includes('Contains uppercase'))).toBe(true);
    });

    test('should validate strong password requirements', async () => {
      await reactiveFormsPage.switchToTab(2);
      
      // Test weak password
      await page.fill('#password', 'weak');
      await page.click('#confirmPassword');
      
      await expect(reactiveFormsPage.hasValidationError('Password must meet all security requirements')).resolves.toBe(true);
      
      // Test strong password
      await page.fill('#password', 'StrongPass123!');
      await page.click('#confirmPassword');
      
      // Should not show password strength error
      await expect(reactiveFormsPage.hasValidationError('Password must meet all security requirements')).resolves.toBe(false);
    });

    test('should validate password confirmation match', async () => {
      await reactiveFormsPage.switchToTab(2);
      
      await page.fill('#password', 'StrongPass123!');
      await page.fill('#confirmPassword', 'DifferentPass123!');
      await page.click('#country');
      
      await expect(reactiveFormsPage.hasValidationError('Passwords do not match')).resolves.toBe(true);
      
      // Fix password confirmation
      await page.fill('#confirmPassword', 'StrongPass123!');
      await page.click('#country');
      
      await expect(reactiveFormsPage.hasValidationError('Passwords do not match')).resolves.toBe(false);
    });
  });

  /**
   * COMPLETE FORM WORKFLOW TESTS
   */
  test.describe('Complete Form Workflows', () => {
    test('should complete entire form successfully', async () => {
      // Tab 1: Basic Information
      await reactiveFormsPage.fillBasicInfo(validUserData.basic);
      
      // Tab 2: Professional Information
      await reactiveFormsPage.switchToTab(1);
      await reactiveFormsPage.fillProfessionalInfo(validUserData.professional);
      
      // Add skills
      for (const skill of validUserData.skills) {
        await reactiveFormsPage.addSkill(skill);
      }
      
      // Tab 3: Security & Preferences
      await reactiveFormsPage.switchToTab(2);
      await reactiveFormsPage.fillSecurityAndPreferences(validUserData.security);
      
      // Submit form
      await reactiveFormsPage.submitForm();
      
      // Should show success notification
      await page.waitForSelector('.notification-success');
      const notification = await page.locator('.notification-message').textContent();
      expect(notification).toContain('User created successfully');
    });

    test('should preserve form data when switching tabs', async () => {
      // Fill basic info
      await reactiveFormsPage.fillBasicInfo(validUserData.basic);
      
      // Switch to professional tab and fill
      await reactiveFormsPage.switchToTab(1);
      await reactiveFormsPage.fillProfessionalInfo(validUserData.professional);
      
      // Switch back to basic info tab
      await reactiveFormsPage.switchToTab(0);
      
      // Data should be preserved
      const usernameValue = await page.inputValue('#username');
      expect(usernameValue).toBe(validUserData.basic.username);
    });

    test('should prevent submission with invalid form', async () => {
      // Fill only basic info (incomplete)
      await reactiveFormsPage.fillBasicInfo(validUserData.basic);
      
      // Try to submit
      await reactiveFormsPage.submitForm();
      
      // Should show warning
      await page.waitForSelector('.notification-warning');
      const notification = await page.locator('.notification-message').textContent();
      expect(notification).toContain('Please fill in all required fields correctly');
    });
  });

  /**
   * FORM UTILITY FEATURES TESTS
   */
  test.describe('Form Utilities', () => {
    test('should reset form to initial state', async () => {
      // Fill some form data
      await reactiveFormsPage.fillBasicInfo(validUserData.basic);
      
      // Reset form
      await reactiveFormsPage.resetForm();
      
      // Form should be empty
      const usernameValue = await page.inputValue('#username');
      expect(usernameValue).toBe('');
      
      // Should be back on first tab
      const currentTab = await reactiveFormsPage.getCurrentTab();
      expect(currentTab).toContain('Basic Info');
    });

    test('should show debug information', async () => {
      await reactiveFormsPage.toggleDebugInfo();
      
      expect(await reactiveFormsPage.isDebugInfoVisible()).toBe(true);
      
      // Should show debug tabs
      const debugTabs = page.locator('.debug-tabs .tab-button');
      await expect(debugTabs).toHaveCount(3);
      
      // Hide debug info
      await reactiveFormsPage.toggleDebugInfo();
      expect(await reactiveFormsPage.isDebugInfoVisible()).toBe(false);
    });

    test('should show current form status in debug info', async () => {
      await reactiveFormsPage.toggleDebugInfo();
      
      // Click on Status tab in debug info
      await page.click('.debug-tabs .tab-button:has-text("Status")');
      
      // Should show form status
      const debugContent = await page.locator('.debug-panel pre').textContent();
      expect(debugContent).toContain('valid');
      expect(debugContent).toContain('invalid');
    });
  });

  /**
   * PERFORMANCE AND RESPONSIVENESS TESTS
   */
  test.describe('Performance', () => {
    test('should handle rapid user input', async () => {
      // Rapidly fill multiple fields
      const startTime = Date.now();
      
      await page.fill('#username', 'rapidtest');
      await page.fill('#email', 'rapid@test.com');
      await page.fill('#firstName', 'Rapid');
      await page.fill('#lastName', 'Test');
      
      const endTime = Date.now();
      const duration = endTime - startTime;
      
      // Should respond quickly
      expect(duration).toBeLessThan(1000);
    });

    test('should handle dynamic control operations efficiently', async () => {
      await reactiveFormsPage.switchToTab(1);
      
      const startTime = Date.now();
      
      // Add multiple skills rapidly
      for (let i = 0; i < 5; i++) {
        await reactiveFormsPage.addSkill(`Skill${i + 1}`);
      }
      
      const endTime = Date.now();
      const duration = endTime - startTime;
      
      // Should remain responsive
      expect(duration).toBeLessThan(2000);
      expect(await reactiveFormsPage.getSkillsCount()).toBe(6); // 1 initial + 5 added
    });
  });

  /**
   * ACCESSIBILITY TESTS
   */
  test.describe('Accessibility', () => {
    test('should support keyboard navigation between tabs', async () => {
      // Focus first tab
      await page.keyboard.press('Tab');
      let focusedElement = await page.locator(':focus').getAttribute('class');
      expect(focusedElement).toContain('tab-button');
      
      // Navigate to next tab with arrow keys (if implemented)
      await page.keyboard.press('ArrowRight');
      // Note: This depends on your tab implementation
    });

    test('should announce form errors to screen readers', async () => {
      // Fill invalid data
      await page.fill('#username', 'ab'); // Too short
      await page.click('#email');
      
      // Error message should be visible and properly structured
      const errorMessage = page.locator('.error-messages small');
      await expect(errorMessage).toBeVisible();
      
      // In a real implementation, you'd check for proper ARIA attributes
      // like aria-describedby, role="alert", etc.
    });
  });

  /**
   * EDGE CASES AND ERROR HANDLING
   */
  test.describe('Edge Cases', () => {
    test('should handle special characters in form fields', async () => {
      const specialData = {
        username: 'user_123',
        email: 'test+special@example.com',
        firstName: 'José',
        lastName: "O'Connor",
        dateOfBirth: '1990-01-01',
        phone: '+1 (555) 123-4567'
      };
      
      await reactiveFormsPage.fillBasicInfo(specialData);
      
      // Form should accept special characters appropriately
      const firstNameValue = await page.inputValue('#firstName');
      expect(firstNameValue).toBe('José');
    });

    test('should handle form state persistence during navigation', async () => {
      // Fill form partially
      await reactiveFormsPage.fillBasicInfo(validUserData.basic);
      
      // Navigate away and back (simulate browser back/forward)
      await page.goto('/');
      await page.goto('/reactive-forms');
      
      // Form should be reset (depending on implementation)
      const usernameValue = await page.inputValue('#username');
      expect(usernameValue).toBe(''); // Assuming form resets on navigation
    });
  });
});
