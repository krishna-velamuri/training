import { test, expect, Page } from '@playwright/test';

/**
 * END-TO-END TESTING CONCEPTS FOR TEMPLATE FORMS:
 * 
 * 1. Page Object Model - Organizing test code using page objects
 * 2. User Journey Testing - Testing complete user workflows
 * 3. Form Interaction Testing - Testing form filling, validation, and submission
 * 4. Multi-step Form Testing - Testing wizard-style form navigation
 * 5. Visual Testing - Testing UI components and layouts
 * 6. Accessibility Testing - Testing keyboard navigation and screen readers
 * 7. Cross-browser Testing - Ensuring compatibility across different browsers
 * 8. Mobile Testing - Testing responsive behavior on mobile devices
 * 9. Error Handling Testing - Testing error states and recovery
 * 10. Performance Testing - Testing load times and responsiveness
 */

/**
 * PAGE OBJECT MODEL
 * 
 * Page objects encapsulate page-specific operations and selectors,
 * making tests more maintainable and reducing code duplication.
 */
class TemplateFormsPage {
  constructor(private page: Page) {}

  // Navigation methods
  async goto() {
    await this.page.goto('/template-forms');
  }

  async goToStep(stepNumber: number) {
    if (stepNumber > 1) {
      for (let i = 1; i < stepNumber; i++) {
        await this.clickNext();
      }
    }
  }

  async clickNext() {
    await this.page.click('button:has-text("Next")');
  }

  async clickPrevious() {
    await this.page.click('button:has-text("Previous")');
  }

  async submitForm() {
    await this.page.click('button:has-text("Submit Form")');
  }

  // Form filling methods
  async fillPersonalInfo(data: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    dateOfBirth: string;
    gender?: string;
    website?: string;
  }) {
    await this.page.fill('#firstName', data.firstName);
    await this.page.fill('#lastName', data.lastName);
    await this.page.fill('#email', data.email);
    await this.page.fill('#phone', data.phone);
    await this.page.fill('#dateOfBirth', data.dateOfBirth);
    
    if (data.gender) {
      await this.page.selectOption('#gender', data.gender);
    }
    
    if (data.website) {
      await this.page.fill('#website', data.website);
    }
  }

  async fillProfessionalInfo(data: {
    company: string;
    position: string;
    experience: string;
    salary?: string;
    skills?: string;
    bio?: string;
  }) {
    await this.page.fill('#company', data.company);
    await this.page.fill('#position', data.position);
    await this.page.fill('#experience', data.experience);
    
    if (data.salary) {
      await this.page.fill('#salary', data.salary);
    }
    
    if (data.skills) {
      await this.page.fill('#skills', data.skills);
    }
    
    if (data.bio) {
      await this.page.fill('#bio', data.bio);
    }
  }

  async fillPreferences(data: {
    country: string;
    contactPreference: 'email' | 'phone' | 'both';
    newsletter?: boolean;
    agreeToTerms: boolean;
  }) {
    await this.page.selectOption('#country', data.country);
    await this.page.check(`input[value="${data.contactPreference}"]`);
    
    if (data.newsletter) {
      await this.page.check('input[name="newsletter"]');
    }
    
    if (data.agreeToTerms) {
      await this.page.check('input[name="agreeToTerms"]');
    }
  }

  // Validation methods
  async getValidationErrors() {
    return await this.page.locator('.error-messages small').allTextContents();
  }

  async hasValidationError(message: string) {
    return await this.page.locator('.error-messages small', { hasText: message }).isVisible();
  }

  async getCurrentStep() {
    const activeStep = await this.page.locator('.progress-step.active .step-number').textContent();
    return parseInt(activeStep || '1');
  }

  async isFieldInvalid(fieldId: string) {
    return await this.page.locator(`#${fieldId}.invalid`).isVisible();
  }

  // Notification methods
  async getNotificationMessage() {
    await this.page.waitForSelector('.notification-message');
    return await this.page.locator('.notification-message').textContent();
  }

  async hasSuccessNotification() {
    return await this.page.locator('.notification-success').isVisible();
  }
}

/**
 * TEST SUITE FOR TEMPLATE FORMS
 */
test.describe('Template Forms - E2E Tests', () => {
  let page: Page;
  let templateFormsPage: TemplateFormsPage;

  // Sample test data
  const validUserData = {
    personal: {
      firstName: 'John',
      lastName: 'Doe',
      email: 'john.doe@example.com',
      phone: '(555) 123-4567',
      dateOfBirth: '1990-01-01',
      gender: 'male',
      website: 'https://johndoe.com'
    },
    professional: {
      company: 'Tech Corporation',
      position: 'Software Engineer',
      experience: '5',
      salary: '75000',
      skills: 'JavaScript, Angular, TypeScript',
      bio: 'Experienced software engineer with a passion for web development.'
    },
    preferences: {
      country: 'United States',
      contactPreference: 'email' as const,
      newsletter: true,
      agreeToTerms: true
    }
  };

  test.beforeEach(async ({ page: testPage }) => {
    page = testPage;
    templateFormsPage = new TemplateFormsPage(page);
    await templateFormsPage.goto();
  });

  /**
   * BASIC NAVIGATION TESTS
   * Testing page load and basic functionality
   */
  test.describe('Basic Navigation', () => {
    test('should load template forms page successfully', async () => {
      // Test page loading
      await expect(page).toHaveTitle(/Angular Training/);
      await expect(page.locator('h1')).toContainText('Template-Driven Forms');
    });

    test('should display form progress indicator', async () => {
      // Test progress indicator visibility
      const progressSteps = page.locator('.progress-step');
      await expect(progressSteps).toHaveCount(3);
      
      const stepLabels = await page.locator('.step-label').allTextContents();
      expect(stepLabels).toEqual(['Personal Info', 'Professional', 'Preferences']);
    });

    test('should start at step 1', async () => {
      // Test initial state
      expect(await templateFormsPage.getCurrentStep()).toBe(1);
      await expect(page.locator('.form-step.active h2')).toContainText('Personal Information');
    });

    test('should show breadcrumb navigation', async () => {
      // Test breadcrumb
      await expect(page.locator('.breadcrumb-current')).toContainText('Template Forms');
      await expect(page.locator('.breadcrumb-link')).toContainText('Home');
    });
  });

  /**
   * FORM VALIDATION TESTS
   * Testing client-side validation rules
   */
  test.describe('Form Validation', () => {
    test('should show required field validation', async () => {
      // Test required field validation
      await page.click('#firstName'); // Focus field
      await page.click('#lastName'); // Blur from firstName
      
      await expect(templateFormsPage.hasValidationError('First name is required')).resolves.toBe(true);
    });

    test('should validate email format', async () => {
      // Test email validation
      await page.fill('#email', 'invalid-email');
      await page.click('#phone'); // Blur from email field
      
      await expect(templateFormsPage.hasValidationError('Please enter a valid email address')).resolves.toBe(true);
    });

    test('should validate phone number format', async () => {
      // Test phone validation
      await page.fill('#phone', '123');
      await page.click('#email'); // Blur from phone field
      
      await expect(templateFormsPage.hasValidationError('Please enter a valid phone number')).resolves.toBe(true);
    });

    test('should validate minimum age requirement', async () => {
      // Test age validation
      const tooYoungDate = new Date();
      tooYoungDate.setFullYear(tooYoungDate.getFullYear() - 10); // 10 years old
      
      await page.fill('#dateOfBirth', tooYoungDate.toISOString().split('T')[0]);
      await page.click('#gender'); // Blur from date field
      
      await expect(templateFormsPage.hasValidationError('You must be at least 16 years old')).resolves.toBe(true);
    });

    test('should validate URL format', async () => {
      // Test URL validation
      await page.fill('#website', 'not-a-url');
      await page.click('#firstName'); // Blur from website field
      
      await expect(templateFormsPage.hasValidationError('Please enter a valid URL')).resolves.toBe(true);
    });

    test('should validate field length requirements', async () => {
      // Test minlength validation
      await page.fill('#firstName', 'A');
      await page.click('#lastName'); // Blur from firstName
      
      await expect(templateFormsPage.hasValidationError('First name must be at least 2 characters')).resolves.toBe(true);
    });
  });

  /**
   * STEP NAVIGATION TESTS
   * Testing multi-step form navigation
   */
  test.describe('Step Navigation', () => {
    test('should not proceed to next step with invalid form', async () => {
      // Test form validation prevents navigation
      await page.click('button:has-text("Next")');
      
      // Should still be on step 1
      expect(await templateFormsPage.getCurrentStep()).toBe(1);
    });

    test('should proceed to next step with valid form', async () => {
      // Fill valid personal information
      await templateFormsPage.fillPersonalInfo(validUserData.personal);
      
      await templateFormsPage.clickNext();
      
      // Should be on step 2
      expect(await templateFormsPage.getCurrentStep()).toBe(2);
      await expect(page.locator('.form-step.active h2')).toContainText('Professional Information');
    });

    test('should navigate backwards through steps', async () => {
      // Go to step 2
      await templateFormsPage.fillPersonalInfo(validUserData.personal);
      await templateFormsPage.clickNext();
      
      // Go back to step 1
      await templateFormsPage.clickPrevious();
      
      expect(await templateFormsPage.getCurrentStep()).toBe(1);
    });

    test('should preserve form data when navigating between steps', async () => {
      // Fill form data
      await templateFormsPage.fillPersonalInfo(validUserData.personal);
      await templateFormsPage.clickNext();
      
      // Go back and check data is preserved
      await templateFormsPage.clickPrevious();
      
      const firstNameValue = await page.inputValue('#firstName');
      expect(firstNameValue).toBe(validUserData.personal.firstName);
    });

    test('should show progress indicator correctly', async () => {
      // Test progress indicator updates
      const checkProgressStep = async (expectedStep: number) => {
        const activeSteps = page.locator('.progress-step.active');
        await expect(activeSteps).toHaveCount(1);
        
        const stepNumber = await activeSteps.locator('.step-number').textContent();
        expect(parseInt(stepNumber || '0')).toBe(expectedStep);
      };
      
      await checkProgressStep(1);
      
      // Move to step 2
      await templateFormsPage.fillPersonalInfo(validUserData.personal);
      await templateFormsPage.clickNext();
      await checkProgressStep(2);
      
      // Move to step 3
      await templateFormsPage.fillProfessionalInfo(validUserData.professional);
      await templateFormsPage.clickNext();
      await checkProgressStep(3);
    });
  });

  /**
   * COMPLETE FORM WORKFLOW TESTS
   * Testing end-to-end user journeys
   */
  test.describe('Complete Form Workflows', () => {
    test('should complete full form successfully', async () => {
      // Step 1: Personal Information
      await templateFormsPage.fillPersonalInfo(validUserData.personal);
      await templateFormsPage.clickNext();
      
      // Step 2: Professional Information
      await templateFormsPage.fillProfessionalInfo(validUserData.professional);
      await templateFormsPage.clickNext();
      
      // Step 3: Preferences
      await templateFormsPage.fillPreferences(validUserData.preferences);
      
      // Submit form
      await templateFormsPage.submitForm();
      
      // Verify success
      await expect(templateFormsPage.hasSuccessNotification()).resolves.toBe(true);
      const notificationMessage = await templateFormsPage.getNotificationMessage();
      expect(notificationMessage).toContain('User created successfully');
    });

    test('should handle form submission with minimum required fields', async () => {
      // Fill only required fields
      const minimalData = {
        personal: {
          firstName: 'Jane',
          lastName: 'Smith',
          email: 'jane@example.com',
          phone: '5551234567',
          dateOfBirth: '1985-05-15'
        },
        professional: {
          company: 'ACME Corp',
          position: 'Developer',
          experience: '3'
        },
        preferences: {
          country: 'Canada',
          contactPreference: 'email' as const,
          agreeToTerms: true
        }
      };
      
      await templateFormsPage.fillPersonalInfo(minimalData.personal);
      await templateFormsPage.clickNext();
      
      await templateFormsPage.fillProfessionalInfo(minimalData.professional);
      await templateFormsPage.clickNext();
      
      await templateFormsPage.fillPreferences(minimalData.preferences);
      await templateFormsPage.submitForm();
      
      await expect(templateFormsPage.hasSuccessNotification()).resolves.toBe(true);
    });

    test('should prevent submission without agreeing to terms', async () => {
      // Fill all form data but don't agree to terms
      await templateFormsPage.fillPersonalInfo(validUserData.personal);
      await templateFormsPage.clickNext();
      
      await templateFormsPage.fillProfessionalInfo(validUserData.professional);
      await templateFormsPage.clickNext();
      
      await page.selectOption('#country', validUserData.preferences.country);
      await page.check(`input[value="${validUserData.preferences.contactPreference}"]`);
      // Don't check terms agreement
      
      // Submit button should be disabled
      const submitButton = page.locator('button:has-text("Submit Form")');
      await expect(submitButton).toBeDisabled();
    });
  });

  /**
   * ACCESSIBILITY TESTS
   * Testing keyboard navigation and screen reader support
   */
  test.describe('Accessibility', () => {
    test('should support keyboard navigation', async () => {
      // Test tab navigation through form fields
      await page.keyboard.press('Tab'); // Should focus first input
      const focusedElement = await page.locator(':focus').getAttribute('id');
      expect(focusedElement).toBe('firstName');
      
      // Tab through several fields
      await page.keyboard.press('Tab');
      await page.keyboard.press('Tab');
      const emailFocused = await page.locator(':focus').getAttribute('id');
      expect(emailFocused).toBe('email');
    });

    test('should have proper form labels', async () => {
      // Test that all inputs have associated labels
      const inputs = await page.locator('input[id]').all();
      
      for (const input of inputs) {
        const inputId = await input.getAttribute('id');
        const label = page.locator(`label[for="${inputId}"]`);
        await expect(label).toBeVisible();
      }
    });

    test('should show error messages for screen readers', async () => {
      // Test that error messages are properly associated with fields
      await page.fill('#firstName', 'A'); // Too short
      await page.click('#lastName'); // Blur to trigger validation
      
      const errorMessage = page.locator('.error-messages small').first();
      await expect(errorMessage).toBeVisible();
      
      // Error message should be readable by screen readers
      const ariaDescribedBy = await page.locator('#firstName').getAttribute('aria-describedby');
      // Note: In a real implementation, you'd want to ensure proper ARIA attributes
    });
  });

  /**
   * RESPONSIVE DESIGN TESTS
   * Testing mobile and tablet layouts
   */
  test.describe('Responsive Design', () => {
    test('should work on mobile viewport', async () => {
      // Set mobile viewport
      await page.setViewportSize({ width: 375, height: 667 });
      
      // Form should still be functional
      await templateFormsPage.fillPersonalInfo({
        firstName: 'Mobile',
        lastName: 'User',
        email: 'mobile@example.com',
        phone: '5551234567',
        dateOfBirth: '1990-01-01'
      });
      
      await templateFormsPage.clickNext();
      expect(await templateFormsPage.getCurrentStep()).toBe(2);
    });

    test('should adapt navigation for mobile', async () => {
      await page.setViewportSize({ width: 375, height: 667 });
      
      // Progress indicator should be visible and functional
      const progressSteps = page.locator('.progress-step');
      await expect(progressSteps).toHaveCount(3);
    });
  });

  /**
   * ERROR HANDLING TESTS
   * Testing error scenarios and recovery
   */
  test.describe('Error Handling', () => {
    test('should handle network errors gracefully', async () => {
      // Fill complete form
      await templateFormsPage.fillPersonalInfo(validUserData.personal);
      await templateFormsPage.clickNext();
      await templateFormsPage.fillProfessionalInfo(validUserData.professional);
      await templateFormsPage.clickNext();
      await templateFormsPage.fillPreferences(validUserData.preferences);
      
      // Simulate network failure (in real app, you might mock API endpoints)
      // For now, we'll test that the form handles submission gracefully
      await templateFormsPage.submitForm();
      
      // Should show loading state
      const submitButton = page.locator('button:has-text("Submitting")');
      await expect(submitButton).toBeVisible({ timeout: 1000 });
    });

    test('should validate all fields when attempting to submit invalid form', async () => {
      // Try to submit empty form from step 3
      await templateFormsPage.goToStep(3);
      
      // Click submit (this should trigger validation)
      const submitButton = page.locator('button[type="submit"]');
      if (await submitButton.isVisible()) {
        await submitButton.click();
      }
      
      // Should show validation warnings
      // Note: The actual behavior depends on form implementation
    });
  });

  /**
   * VISUAL REGRESSION TESTS
   * Testing UI consistency
   */
  test.describe('Visual Testing', () => {
    test('should maintain consistent styling across steps', async () => {
      // Take screenshot of step 1
      await expect(page).toHaveScreenshot('template-forms-step-1.png');
      
      // Navigate to step 2 and screenshot
      await templateFormsPage.fillPersonalInfo(validUserData.personal);
      await templateFormsPage.clickNext();
      await expect(page).toHaveScreenshot('template-forms-step-2.png');
      
      // Navigate to step 3 and screenshot
      await templateFormsPage.fillProfessionalInfo(validUserData.professional);
      await templateFormsPage.clickNext();
      await expect(page).toHaveScreenshot('template-forms-step-3.png');
    });

    test('should display validation errors consistently', async () => {
      // Trigger validation errors
      await page.click('#firstName');
      await page.click('#lastName');
      await page.fill('#email', 'invalid-email');
      await page.click('#phone');
      
      // Wait for validation to appear
      await page.waitForSelector('.error-messages');
      await expect(page).toHaveScreenshot('template-forms-validation-errors.png');
    });
  });

  /**
   * PERFORMANCE TESTS
   * Testing load times and responsiveness
   */
  test.describe('Performance', () => {
    test('should load form quickly', async () => {
      const startTime = Date.now();
      await templateFormsPage.goto();
      
      // Wait for form to be interactive
      await page.waitForSelector('#firstName');
      const loadTime = Date.now() - startTime;
      
      // Should load within reasonable time (adjust threshold as needed)
      expect(loadTime).toBeLessThan(3000);
    });

    test('should respond quickly to user input', async () => {
      // Test input responsiveness
      const startTime = Date.now();
      await page.fill('#firstName', 'Performance Test');
      const responseTime = Date.now() - startTime;
      
      // Should respond immediately
      expect(responseTime).toBeLessThan(100);
    });
  });
});

/**
 * CROSS-BROWSER COMPATIBILITY TESTS
 * These tests will run across all configured browsers in playwright.config.ts
 */
test.describe('Cross-Browser Compatibility', () => {
  test('should work consistently across browsers', async ({ page, browserName }) => {
    const templateFormsPage = new TemplateFormsPage(page);
    await templateFormsPage.goto();
    
    // Basic functionality should work in all browsers
    await templateFormsPage.fillPersonalInfo({
      firstName: `Test-${browserName}`,
      lastName: 'User',
      email: `test-${browserName}@example.com`,
      phone: '5551234567',
      dateOfBirth: '1990-01-01'
    });
    
    await templateFormsPage.clickNext();
    expect(await templateFormsPage.getCurrentStep()).toBe(2);
  });
});
